<?php

namespace App\Http\Controllers\API\DB;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class TriggerController extends Controller
{
    
}
