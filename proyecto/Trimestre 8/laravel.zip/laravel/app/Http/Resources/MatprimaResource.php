<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class MatprimaResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return[
            'id'=>$this->id,
            'referencia'=>$this->referencia,
            'descripcion'=>$this->descripcion,
            'existencia'=>$this->existencia,
            'entrada'=>$this->entrada,
            'salida'=>$this->salida,
            'stock'=>$this->stock,
            'created_at'=>$this->created_at->toDateTimeString(),
            'updated_at'=>$this->updated_at->toDateTimeString()
        ];
    }
}
