import { useState } from 'react';
import { styled } from '@mui/material/styles';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import InputLabel from '@mui/material/InputLabel';
import FormHelperText from '@mui/material/FormHelperText';
import { useFormik } from 'formik';
import { sendSuggestion } from '../../../services/pqr';
import * as yup from 'yup';

// Estilo para los campos
const FieldWrapper = styled('div')(({ theme }) => ({
    marginBottom: theme.spacing(2), // Ajusta el margen inferior
    width: '100%', // Asegura que los campos ocupen todo el ancho disponible
    boxSizing: 'border-box', // Incluye padding y border en el ancho total
}));

// Estilo para el contenedor del botón
const ButtonWrapper = styled('div')({
    display: 'flex',
    justifyContent: 'center', // Centra el botón horizontalmente
    marginTop: '1rem', // Espacio superior del botón
});

// Esquema de validación
const validationSchema = yup.object({
    tipo_suge: yup
        .string()
        .required('El tipo de sugerencia es obligatorio'),  // Campo requerido
    sugerencia: yup
        .string()
        .required('La sugerencia es obligatoria')  // Campo requerido
        .min(10, 'La sugerencia debe tener al menos 10 caracteres'),  // Longitud mínima
});


// Campos de registro
const CamposRegistro = () => {
    const [submitted, setSubmitted] = useState(false); // Estado para manejar si el formulario ha sido enviado

    const formik = useFormik({
        initialValues: {
            tipo_suge: '',
            sugerencia: '',
        },
        validationSchema: validationSchema,  // Añadimos el esquema de validación

        onSubmit: async (values) => { // Marcar la función como async
            try {
                console.log('Datos enviados:', values);

                // Verificación del token
                const userSession = JSON.parse(sessionStorage.getItem('user'));
                const token = userSession?.token?.access_token;

                if (!token) {
                    console.error('No se encontró un token de acceso. Asegúrate de estar autenticado.');
                    return;
                }

                // Llama al método de envío del servicio pqr
                await sendSuggestion(values);
                console.log('Sugerencia enviada con éxito:', values);
            } catch (error) {
                if (error.response) {
                    // El servidor respondió con un código de estado fuera del rango 2xx
                    console.error('Detalle del error:', error.response.data);
                    alert(`Error ${error.response.status}: ${error.response.data.message}`);
                } else if (error.request) {
                    // La solicitud fue hecha pero no se recibió respuesta
                    console.error('Error al enviar la sugerencia:', error.request);
                } else {
                    // Algo pasó al configurar la solicitud que desencadenó un error
                    console.error('Error al enviar la sugerencia:', error.message);
                }
            }
        },
    });

    const handleSubmit = (e) => {
        e.preventDefault();
        setSubmitted(true); // Marca el formulario como enviado
        formik.handleSubmit(); // Envía el formulario si es válido
    };

    return (
        <form onSubmit={handleSubmit}>

            {/* Campo Tipo de Sugerencia */}
            <FieldWrapper>
                <FormControl
                    fullWidth
                    error={submitted && Boolean(formik.errors.tipo_suge)}
                    variant="outlined"
                    sx={{ boxSizing: 'border-box' }} // Evita el desbordamiento
                >
                    <InputLabel id="tipo_suge-label">Tipo de Sugerencia</InputLabel>
                    <Select
                        labelId="tipo_suge-label"
                        id="tipo_suge"
                        name="tipo_suge"
                        value={formik.values.tipo_suge}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                        label="Tipo de Sugerencia"
                        sx={{ boxSizing: 'border-box' }} // Evita el desbordamiento
                    >
                        <MenuItem value=""><em>Ninguno</em></MenuItem>
                        <MenuItem value="queja">Queja</MenuItem>
                        <MenuItem value="reclamo">Reclamo</MenuItem>
                        <MenuItem value="sugerencia">Sugerencia</MenuItem>
                    </Select>
                    {submitted && formik.errors.tipo_suge ? (
                        <FormHelperText>{formik.errors.tipo_suge}</FormHelperText>
                    ) : null}
                </FormControl>
            </FieldWrapper>

            {/* Campo Sugerencia */}
            <FieldWrapper>
                <TextField
                    id="sugerencia"
                    name="sugerencia"
                    label="Sugerencia"
                    multiline
                    rows={4}
                    value={formik.values.sugerencia}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    error={submitted && Boolean(formik.errors.sugerencia)}
                    helperText={submitted && formik.errors.sugerencia}
                    fullWidth
                    variant="outlined"
                />
            </FieldWrapper>

            {/* Botón Enviar */}
            <ButtonWrapper>
                <Button color="primary" variant="contained" type="submit">
                    Enviar
                </Button>
            </ButtonWrapper>
        </form>
    );
};

export default CamposRegistro;
