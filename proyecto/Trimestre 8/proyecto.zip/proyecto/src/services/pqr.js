import axios from 'axios'; // Asegúrate de que axios esté importado

// Definir la función sendSuggestion
export const sendSuggestion = async (suggestionData) => {
    const userSession = JSON.parse(sessionStorage.getItem('user'));
    const token = userSession?.token?.access_token;

    if (!token) {
        throw new Error('No se encontró un token de acceso.');
    }

    try {
        const response = await axios.post('http://arcaweb.test/api/V1/pqrs', suggestionData, {
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json',
            },
        });
        return response.data;
    } catch (error) {
        if (error.response) {
            // Si el servidor responde con un error, captúralo y lánzalo de nuevo
            throw new Error(`Error del servidor: ${error.response.data.error}`);
        } else {
            throw new Error('Error desconocido');
        }
    }
};
